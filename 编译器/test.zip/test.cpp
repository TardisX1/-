 
#include<iostream>
#define abcd  10

	
int main(){
	//abcd                    
	using namespace std;
	
	int abcd ;
	char[] str="abcd";
	return 0;
}
